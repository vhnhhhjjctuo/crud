 const express = require('express');
 const server = express()
 const port = 3090
 server.use(express.json())

 const produtos = ['maça', 'feijão', 'arroz'];


 server.get('/produtos/:index' , (req, res) => {
     const { index } = req.params;
     return res.json(produtos[index]);
 });

 
 // RETORNAR TODOS OS PRODUTOS
server.get('/produtos' , (req, res ) => {
    return res.json(produtos)
});

// CRIAR UM NOVO PRODUTO
server.post('/produtos',(req, res) => {
    const { name } = req.body;
    produtos.push(name);

    return res.json(produtos)
});

// ATUALIZAR UM PRODUTO
server.put('/produtos/:index', (req, res) => {
    const { index } = req.params;
    const { name } = req.body;

    produtos[index] = name;

    return res.json(produtos)
});

//DELETAR PRODUTO
server.delete('/produtos/:index', (req, res) => {
    const { index } = req.params;

    produtos.splice(index, 1);
    return res.json({message: "o produto foi deletado"});
});


server.listen(port, () => {
    console.log('servidor rodando')
 });  






