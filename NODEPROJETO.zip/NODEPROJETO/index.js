const express = require('express')
const app = express()
const port = 3100

const treinos = require('./treinos.json')

app.get('/treinos', (req, res) => {
    return res.json(treinos)
});
app.listen(port, () => {
    console.log('servidor rodando')
});
