let somaFunction = require('./funcion/soma')
let subFunction = require('./funcion/sub')
let multFunction = require('./funcion/mult')
let divFunction = require('./funcion/divisao')



console.log(divFunction(5,5))

