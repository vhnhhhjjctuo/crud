let divisao = function(a,b) {
    return (a/b);
}

module.exports = divisao