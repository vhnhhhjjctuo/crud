let subtração = function(a,b){
    return (a-b)
}
     module.exports = subtração