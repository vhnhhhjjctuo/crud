const express = require('express')
const app = express()

app.get('/', (req, res)=> res.send ('Ola, usuario'));
app.get ('/produtos', (req, res)=> {
  const produtos = [
    {
        id: 1,
        name: "shampoo",
    },
    {
        id: 2,
        name: "condicionador",
    },
    {
        id: 3,
        name: "sabonete",
    },
]
res.json(produtos);
});

app.get('/hello/:nome', function(req,res){
    res.send(req.params);
})
app.listen(9091,function(){
    console.log('servidor rodando')
});

